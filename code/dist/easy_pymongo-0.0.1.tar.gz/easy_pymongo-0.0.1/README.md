# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://www.github.com/Matthew-Ye/easy_mongo/)
to write your content.